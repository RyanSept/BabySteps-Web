For best experience, open the file 'christmas.html' using Firefox or Chrome.
Click the christmas tree at th e bottom of the page to start.